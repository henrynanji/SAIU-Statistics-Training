#============================================================================

#  Exercise

# SESSION II | Analysis of numerical outcome variable 

#============================================================================
# Packages to be installed - Run each line of code to install the packages

if (!require("readxl")){ install.packages("readxl")}
if (!require("readr")){ install.packages("(readr")}
if (!require("dplyr")){ install.packages("dplyr")}
if (!require("ggplot2")){ install.packages("ggplot2")}
if (!require("tidyverse")){ install.packages("tidyverse")}
if (!require("lawstat")){ install.packages("lawstat")}
if (!require("moments")){ install.packages("moments")}


# Load packages: Run each line of code to load the library

library(readxl)
library(readr)
library(dplyr)
library(ggplot2)
library(tidyverse)
library(lawstat)
library(moments)

#===============================================================================
# Importing the data set
sample_data2 <- read_csv("sample_data2.csv")
#===============================================================================

# obtain column names

names(sample_data2)

#===============================================================================
# Task 1: For the following variables, cost, cholesterol, and resting blood pressure,
# verify if the outcome is normally distributed or skewed. Apply all the methods/test
# that you have learnt to verify the distribution of the outcome.

# Task II )	Decide on an appropriate statistical test and assess the impact of
# gender for each outcome
#===============================================================================

# outcome variable 1 : Cost

# Calculate the mean

summary(sample_data2$Cost)

# Question : is the mean higher or lower than the median. What does this indicate about the distribution?
# (normally distributed or skewed)


# visualize cost if it is normally distributed or not

ggplot(data = sample_data2 , mapping = aes(x = Cost), binwidth = 5) +
  geom_histogram()


# alternatively, visualize cost using base R if it is normally distributed or not

plot(density(sample_data2$Cost)) # uses base R

# quantile-quantile (QQ) plot

ggplot(sample_data2, aes(sample = Cost)) +
  geom_qq() +
  geom_qq_line() # Normally distributed, except at the edges

# check the variance in cost between males and females
mean.sd_gender <-sample_data2 %>%
  group_by(Gender)%>% 
  summarize(mean = mean(Cost),
            sd = sd(Cost))
mean.sd_gender  # standard deviation is similar

# test if the mean difference in cost for males and females is statistically significant

t.test(Cost ~ Gender, sample_data2) 

# what is the mean cost for males and females?
# Is the mean cost higher in males or in females
# is the p value within the statistically significant range
# what conclusion can you draw about the mean value of cost between males and females

#===============================================================================
#===============================================================================
# outcome variable 2 : Cholesterol

names(sample_data2)

# replace variable 2 with cholesterol

summary(sample_data2$variable2)

# compare the mean and the median from the output above, are they similar


# Visualize the data if it is normally distributed or skewed?
# replace variable 2 with cholesterol

ggplot(data = sample_data2 , mapping = aes(x = variable2), binwidth = 5) +
  geom_histogram()  # skewed


# quantile - quantile (QQ) plot

# replace variable 2 with cholesterol

ggplot(sample_data2, aes(sample = variable2)) +
  geom_qq() +
  geom_qq_line()  

# is cholesterol normally distributed or not

# what statistical test would you apply to test the mean difference in cholesterol 

# replace var1 and var2 accordingly

wilcox.test(var1 ~ var2, sample_data2) 

# Is the difference between mean cholesterol in males and females statistically significant?


# amend the code below to obtain the median, lower quartile, upper quartile
# for cholesterol in males and females

# replace variable 1 with Gender

# replace variable 2 with cholesterol

median_by_gender <- sample_data2 %>%
  group_by(variable1) %>% 
  summarise(
    median = median(variable2, na.rm = TRUE),
    lower_quartile = quantile(variable2, 0.25, na.rm = TRUE),
    upper_quartile = quantile(variable2, 0.75, na.rm = TRUE),
    IQR = IQR(variable2, na.rm = TRUE)
  )

median_by_gender


#===============================================================================
#===============================================================================

# outcome variable 3 : resting blood pressure: RestingBP

# replace var1 with RestingBP


summary(sample_data2$var1)

# visualize the data if it is normally distributed

# replace var1 with RestingBP

ggplot(data = sample_data2 , mapping = aes(x = var1), binwidth = 5) +
  geom_histogram()

# quantile-quantile (QQ) plot

# replace var1 with RestingBP

ggplot(sample_data2, aes(sample = var1)) +
  geom_qq() +
  geom_qq_line()

# check the standard deviation in each group

# replace var1 and var2 with RestingBP and Gender
mean.sd_gender <-sample_data2 %>%
  group_by(var2)%>% 
  summarize(mean = mean(var1),
            sd = sd(var1))
mean.sd_gender 


# t- test

# replace var1 and var2 with RestingBP and Gender

t.test(var1 ~ var2, sample_data2)

# Interpret your results



