
#============================================================================

# SESSION II | Analysis of numerical outcome variable

#============================================================================
# Packages to be installed - Run each line of code to install the packages

if (!require("readxl")){ install.packages("readxl")}
if (!require("readr")){ install.packages("(readr")}
if (!require("dplyr")){ install.packages("dplyr")}
if (!require("ggplot2")){ install.packages("ggplot2")}
if (!require("tidyverse")){ install.packages("tidyverse")}
if (!require("lawstat")){ install.packages("lawstat")}
if (!require("moments")){ install.packages("moments")}


# Load packages: Run each line of code to load the library

library(readxl)
library(readr)
library(dplyr)
library(ggplot2)
library(tidyverse)
library(lawstat)
library(moments)



#===============================================================
# Analysis of numerical outcome variable : NORMALLY DISTRIBUTED VARIABLE
#================================================================

# here we will be using the handover data, this is a simulated data set

# We are going to check if the data meets the requirement for a data that is normally distributed

handover_data <- read_csv("emas_normal_data.csv")

# using the head() /Tail() functions, we can view  columns names and a few records

head(handover_data)

tail(handover_data)

# summarize the handover time to  obtain the mean and median

summary(handover_data$handover_time)  # ===> mean and median are very similar - this is an indication that handover time is normally distributed

# visualize handover time if it is normally distributed

ggplot(data = handover_data , mapping = aes(x = handover_time), binwidth = 5) +
  geom_histogram()

# alternatively, visualize handover time using base R if it is normally distributed 

plot(density(handover_data$handover_time)) # uses base R


# quantile-quantile (QQ) plot or Inverse normal plot

ggplot(handover_data, aes(sample = handover_time)) +
  geom_qq() +
  geom_qq_line()


# we are going to check if the handover time is normally distributed in both groups - in this case for males and females

ggplot(data = handover_data , mapping = aes(x = handover_time), binwidth = 5) +
  geom_histogram() +  facet_wrap(~gender)


# Test for equal variances | check the standard deviation in each group
mean.sd_gender <-handover_data %>%
  group_by(gender)%>% 
  summarize(mean = mean(handover_time),
            sd = sd(handover_time))
mean.sd_gender


# levene test from lawstat package is used to test for equal variances
# P value > 0.05 suggest that the variable is normally distributed
levene.test(handover_data$handover_time, handover_data$gender, location="mean")


# Shapiro-Wilk test for normality  | P value > 0.05 implies that the data is normally distributed

shapiro.test(handover_data$handover_time)

# # here i am creating a simulated data to apply the Shapiro-Wilk test for normality 
mean <- 0  # Mean of the distribution
sd <- 1    # Standard deviation of the distribution
n <- 5000  # Number of samples

# Generate 5000 samples from a normal distribution
data <- rnorm(n, mean, sd)

plot(density(data)) 

shapiro.test(data)


# Skewness of distribution  |  symmetrically distributed if skewness = 0, right skewed (positive) , left skewed(negative)
skewness(handover_data$handover_time)


#===============================================================================
# PARAMETRIC TEST, t - test
#===============================================================================
# This test if there is a statistically difference in handover times between males and females

t.test(handover_time ~ gender, handover_data)

# This test if there is a statistically difference in cholesterol between males and females

t.test(cholesterol ~ gender, handover_data)


#  Linear regression  - adjusting for other factors

mod1 = lm(handover_time ~ gender, data=handover_data)
summary(mod1)
coef(mod1)


#===============================================================
# Analysis of numerical outcome variable : SKEWED VARIABLE
#================================================================

# this is real data

emas <- read_csv("emas.csv")

#  filtering out other categories of gender

emas <- emas %>% filter(Patient_Gender == "Female" | Patient_Gender =="Male") 

summary(emas$Handover_Seconds)


ggplot(data = emas, mapping = aes(x = Handover_Seconds), binwidth = 5) +
  geom_histogram()

# quantile-quantile (QQ) plot

ggplot(emas, aes(sample = Handover_Seconds)) +
  geom_qq() +
  geom_qq_line()

# we can go ahead to perform the other checks, but clearly, handover time is very skewed


#===============================================================================
# NON PARAMETRIC TEST - Wilcoxon Rank sum test
#===============================================================================
# test whether the mean difference between mean handover time is statistically different between males and females

# Mann–Whitney U test) to assess whether the observations are sampled from the same probability distribution 
# (that is, whether the probability of
# obtaining higher handover time is greater in one population compared to the other).


# here is the format to implement the test in R

wilcox.test(y ~ x, data)  # where y is numeric and x is a dichotomous variable
wilcox.test(y1, y2)  # where y1 and y2 are the outcome variables for each group


table(emas$Patient_Gender)


wilcox.test(Handover_Seconds ~ as.factor(Patient_Gender), emas)

# you can reject the hypothesis that median handover times  the same in  males and females (p < .001)
# when outcome variable is not normally distributed, we should report the median

median_bysex <- emas %>%
  group_by(Patient_Gender) %>% 
  summarise(
    mean = mean(Handover_Seconds, na.rm = TRUE),
    median = median(Handover_Seconds, na.rm = TRUE),
    lower_quartile = quantile(Handover_Seconds, 0.25, na.rm = TRUE),
    upper_quartile = quantile(Handover_Seconds, 0.75, na.rm = TRUE),
    IQR = IQR(Handover_Seconds, na.rm = TRUE)
  )

median_bysex


#===============================================================================
# CORRELATION
#===============================================================================
# correlation between age standardized rate and deprivation score

df <- read_csv("sample_data1.csv")


# Pearson correlation 

pearsoncorr = cor(df$age_standardized_rate, df$deprivation)
pearsoncorr

# test for statistical significance
cor.test(df$age_standardized_rate, df$deprivation)

# visualize the relationship
ggplot(data = df, aes(x = deprivation, y = age_standardized_rate)) +
  geom_point(alpha = 0.5) +
  geom_smooth(method = "lm", color = "blue", se = FALSE) +
  labs(title = "Scatter Plot of age standardisede rate vs deprivation",
       x = "IMD Deprivation scores",
       y = "Age standardised rate") +
  theme_minimal()



#spearmancorr = cor(x, y, method="spearman")
#kendalltau = cor(x, y, method="kendall")


